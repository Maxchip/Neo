USE [DB_A1F758_neo]
GO
/****** Object:  Sequence [dbo].[SeqNumCartaCob]    Script Date: 03/11/2017 14:43:53 ******/
CREATE SEQUENCE [dbo].[SeqNumCartaCob] 
 AS [int]
 START WITH 1
 INCREMENT BY 1
 MINVALUE -2147483648
 MAXVALUE 2147483647
 CACHE 
GO

USE [DB_A1F758_neo]
GO
/****** Object:  Sequence [dbo].[SeqNumNotaDeb]    Script Date: 03/11/2017 14:43:53 ******/
CREATE SEQUENCE [dbo].[SeqNumNotaDeb] 
 AS [int]
 START WITH 1
 INCREMENT BY 1
 MINVALUE -2147483648
 MAXVALUE 2147483647
 CACHE 
GO